import type { UpdateLifecycleObservedProps } from '../update-lifecycle.js';
/**
 * @module analytics/events/event-payload
 * Discriminated union of all analytics event payloads.
 */
import type { AnalyticsEventName } from './event-names.js';
import type { AmrAuthStageProps } from './amr-auth.js';
import type { DesignSystemApplyResultProps, DesignSystemCreateResultProps, DesignSystemEnrichResultProps, DesignSystemReviewResultProps, DesignSystemSourceIngestResultProps, DesignSystemStatusResultProps } from './design-systems.js';
import type { OnboardingCompletedProps, OnboardingCompleteResultProps, OnboardingFirstGenerationCompletedProps, OnboardingFirstPromptSentProps, OnboardingPromptPrefilledProps, OnboardingRuntimeScanResultProps } from './onboarding.js';
import type { PageViewProps } from './page-view.js';
import type {
  AgentDetectDiagnosticProps, ArtifactDeployResultProps, ChatArtifactCaptureResultProps, ArtifactEditResultProps, ArtifactExportResultProps, ArtifactPublishResultProps, AssistantFeedbackClickProps, AssistantFeedbackReasonClickProps, AssistantFeedbackReasonSubmitProps, AssistantFeedbackReasonViewProps, ByokPreflightBlockedProps, ContextLinkResultProps, ConversationForkResultProps, FeedbackSubmitResultProps, FileUploadResultProps, FileVersionRestoreResultProps, LabsItemToggledProps, LangfuseReportResultProps, MediaGenerationResultProps, PackagedRuntimeFailedProps, PluginImportResultProps, PluginReplacementResultProps, ProjectCreateResultProps, RunCreatedProps, RunFinishedProps, RunRetryAttemptedProps, RunRetryFinishedProps, SettingsByokModelsFetchResultProps, SettingsByokTestResultProps, SettingsCliTestResultProps, SettingsConnectorAuthResultProps, SettingsViewProps, SketchExportResultProps, SketchSaveResultProps, SpeakerNotesSaveResultProps, UpdateApplyObservedProps, UpdateCheckResultProps, UpdateInstallResultProps } from './result-events.js';
import type { SurfaceViewProps } from './surface-view.js';
import type { AmrAuthResultProps, UiClickProps } from './ui-click.js';
import type {
  McpSessionInitializedProps,
  McpToolFinishedProps,
  McpToolStartedProps,
} from './mcp.js';
import type { ProjectCommentCreateResultProps, WorkspaceInviteResultProps, WorkspaceProjectActionResultProps, WorkspaceResourceActionResultProps, WorkspaceSharedProjectOpenResultProps, WorkspaceSwitchResultProps } from './workspace.js';
// ---- Discriminated union of all event payloads ---------------------------

export type AnalyticsEventPayload =
  | { event: 'packaged_runtime_failed'; props: PackagedRuntimeFailedProps }
  | { event: 'page_view'; props: PageViewProps }
  | { event: 'ui_click'; props: UiClickProps }
  | { event: 'surface_view'; props: SurfaceViewProps }
  | { event: 'project_create_result'; props: ProjectCreateResultProps }
  | { event: 'plugin_replacement_result'; props: PluginReplacementResultProps }
  | { event: 'plugin_import_result'; props: PluginImportResultProps }
  | { event: 'run_created'; props: RunCreatedProps }
  | { event: 'run_finished'; props: RunFinishedProps }
  | { event: 'langfuse_report_result'; props: LangfuseReportResultProps }
  | { event: 'run_retry_attempted'; props: RunRetryAttemptedProps }
  | { event: 'run_retry_finished'; props: RunRetryFinishedProps }
  | { event: 'mcp_session_initialized'; props: McpSessionInitializedProps }
  | { event: 'mcp_tool_started'; props: McpToolStartedProps }
  | { event: 'mcp_tool_finished'; props: McpToolFinishedProps }
  | { event: 'media_generation_result'; props: MediaGenerationResultProps }
  | { event: 'chat_artifact_capture_result'; props: ChatArtifactCaptureResultProps }
  | { event: 'update_install_result'; props: UpdateInstallResultProps }
  | { event: 'update_check_result'; props: UpdateCheckResultProps }
  | { event: 'update_apply_observed'; props: UpdateApplyObservedProps }
  | { event: 'update_lifecycle_observed'; props: UpdateLifecycleObservedProps }
  | { event: 'file_upload_result'; props: FileUploadResultProps }
  | { event: 'context_link_result'; props: ContextLinkResultProps }
  | { event: 'speaker_notes_save_result'; props: SpeakerNotesSaveResultProps }
  | { event: 'artifact_edit_result'; props: ArtifactEditResultProps }
  | { event: 'artifact_export_result'; props: ArtifactExportResultProps }
  | { event: 'artifact_deploy_result'; props: ArtifactDeployResultProps }
  | { event: 'artifact_publish_result'; props: ArtifactPublishResultProps }
  | { event: 'sketch_save_result'; props: SketchSaveResultProps }
  | { event: 'sketch_export_result'; props: SketchExportResultProps }
  | { event: 'file_version_restore_result'; props: FileVersionRestoreResultProps }
  | { event: 'workspace_switch_result'; props: WorkspaceSwitchResultProps }
  | { event: 'workspace_invite_result'; props: WorkspaceInviteResultProps }
  | { event: 'workspace_project_action_result'; props: WorkspaceProjectActionResultProps }
  | { event: 'workspace_shared_project_open_result'; props: WorkspaceSharedProjectOpenResultProps }
  | { event: 'workspace_resource_action_result'; props: WorkspaceResourceActionResultProps }
  | { event: 'project_comment_create_result'; props: ProjectCommentCreateResultProps }
  | { event: 'conversation_fork_result'; props: ConversationForkResultProps }
  | { event: 'feedback_submit_result'; props: FeedbackSubmitResultProps }
  | { event: 'assistant_feedback_click'; props: AssistantFeedbackClickProps }
  | {
      event: 'assistant_feedback_reason_view';
      props: AssistantFeedbackReasonViewProps;
    }
  | {
      event: 'assistant_feedback_reason_click';
      props: AssistantFeedbackReasonClickProps;
    }
  | {
      event: 'assistant_feedback_reason_submit';
      props: AssistantFeedbackReasonSubmitProps;
    }
  | { event: 'settings_view'; props: SettingsViewProps }
  | { event: 'labs_item_toggled'; props: LabsItemToggledProps }
  | { event: 'settings_cli_test_result'; props: SettingsCliTestResultProps }
  | { event: 'settings_byok_test_result'; props: SettingsByokTestResultProps }
  | {
      event: 'settings_byok_models_fetch_result';
      props: SettingsByokModelsFetchResultProps;
    }
  | { event: 'byok_preflight_blocked'; props: ByokPreflightBlockedProps }
  | { event: 'settings_connector_auth_result'; props: SettingsConnectorAuthResultProps }
  | { event: 'agent_detect_diagnostic'; props: AgentDetectDiagnosticProps }
  | { event: 'amr_auth_stage'; props: AmrAuthStageProps }
  | { event: 'amr_auth_result'; props: AmrAuthResultProps }
  | { event: 'onboarding_runtime_scan_result'; props: OnboardingRuntimeScanResultProps }
  | { event: 'onboarding_complete_result'; props: OnboardingCompleteResultProps }
  | { event: 'onboarding_prompt_prefilled'; props: OnboardingPromptPrefilledProps }
  | { event: 'onboarding_first_prompt_sent'; props: OnboardingFirstPromptSentProps }
  | {
      event: 'onboarding_first_generation_completed';
      props: OnboardingFirstGenerationCompletedProps;
    }
  | { event: 'onboarding_completed'; props: OnboardingCompletedProps }
  | {
      event: 'design_system_source_ingest_result';
      props: DesignSystemSourceIngestResultProps;
    }
  | { event: 'design_system_create_result'; props: DesignSystemCreateResultProps }
  | { event: 'design_system_review_result'; props: DesignSystemReviewResultProps }
  | { event: 'design_system_status_result'; props: DesignSystemStatusResultProps }
  | { event: 'design_system_apply_result'; props: DesignSystemApplyResultProps }
  | { event: 'design_system_enrich_result'; props: DesignSystemEnrichResultProps };

// Compile-time guard: `AnalyticsEventName` (event-names.ts) and the payload
// discriminants above must stay in sync. If a future catalog split drops or
// adds an event name on only one side, `AnalyticsEventCatalogDrift` stops being
// `never` and the assertion below fails to type-check — reconcile the two files
// rather than letting the public contract diverge. Downstream code that
// validates or switches on `AnalyticsEventName` relies on this parity.
type AnalyticsEventCatalogDrift =
  | Exclude<AnalyticsEventName, AnalyticsEventPayload['event']>
  | Exclude<AnalyticsEventPayload['event'], AnalyticsEventName>;
// The default type argument must satisfy `extends never`; any drift makes it a
// non-`never` union and turns this alias into a type error.
type AssertAnalyticsEventCatalogInSync<
  _Drift extends never = AnalyticsEventCatalogDrift,
> = _Drift;

// Virtualized deck thumbnail rail (film strip) for the deck preview.
//
// The naive shape — one `<iframe srcDoc={whole deck}>` per slide, all mounted
// eagerly — made every deck open execute the full deck N+1 times: N×
// buildSrcdoc on every source change plus N live documents each running every
// slide's scripts, fonts and animations. On real decks that saturates main
// thread and compositor (the user-visible symptom is the stage and rail
// blacking out under GPU memory pressure).
//
// Contract:
// - srcdoc strings are built LAZILY, once per slide, only when that slide's
//   thumbnail actually needs a live iframe; cached until `buildThumbSrcDoc`
//   identity changes (i.e. the deck source changed).
// - Only thumbnails near the rail viewport hold a live iframe; far-away
//   slides render an empty numbered frame. Once seen, a slide stays mounted
//   while it remains inside the recently-visible LRU window so scrolling back
//   never re-parses the document; the cap bounds worst-case (100-slide)
//   decks. The active slide is always mounted so navigation never lands on an
//   empty frame.
// - Thumbnail documents are built by the host with `freezeMotion` so looping
//   deck animations settle at their final frame instead of keeping N
//   compositor layers rasterizing forever.

import {
  memo,
  useCallback,
  useEffect,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
  type RefObject,
} from 'react';
import { useT } from '../i18n';
import { useInView } from './plugins-home/useInView';
import { DeckSlideThumbnail } from './DeckSlideThumbnail';
import type { ParsedDeckThumbnails } from '../runtime/deck-thumbnail-parser';

/**
 * Upper bound on concurrently mounted thumbnail iframes. Currently-visible
 * thumbnails and the active slide are never evicted, so the effective cap is
 * `max(cap, visible + active)`; the constant only bounds the keep-alive tail
 * for very long decks.
 */
export const MOUNTED_THUMBNAIL_CAP = 16;

const useIsomorphicLayoutEffect = typeof window !== 'undefined' ? useLayoutEffect : useEffect;

export interface DeckThumbnailViewport {
  width: number;
  height: number;
}

interface DeckIframeThumbnailProps {
  label: string;
  srcDoc: string;
  previewViewport?: DeckThumbnailViewport | null;
  onReady: () => void;
}

function DeckIframeThumbnail({
  label,
  srcDoc,
  previewViewport,
  onReady,
}: DeckIframeThumbnailProps) {
  const hostRef = useRef<HTMLDivElement | null>(null);
  const frameRef = useRef<HTMLIFrameElement | null>(null);

  useIsomorphicLayoutEffect(() => {
    const host = hostRef.current;
    const frame = frameRef.current;
    if (!host || !frame) return;
    const apply = () => {
      const hostWidth = host.clientWidth;
      const hostHeight = host.clientHeight;
      if (!hostWidth || !hostHeight) return;
      const hasPreviewViewport = !!previewViewport
        && Number.isFinite(previewViewport.width)
        && previewViewport.width > 0
        && Number.isFinite(previewViewport.height)
        && previewViewport.height > 0;
      const viewportWidth = hasPreviewViewport ? previewViewport.width : hostWidth * 2;
      const viewportHeight = hasPreviewViewport ? previewViewport.height : hostHeight * 2;
      const scale = Math.min(hostWidth / viewportWidth, hostHeight / viewportHeight);
      frame.style.width = `${viewportWidth}px`;
      frame.style.height = `${viewportHeight}px`;
      frame.style.transform = `scale(${scale})`;
      frame.style.left = `${(hostWidth - viewportWidth * scale) / 2}px`;
      frame.style.top = `${(hostHeight - viewportHeight * scale) / 2}px`;
    };
    apply();
    const observer = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(apply) : null;
    observer?.observe(host);
    return () => observer?.disconnect();
  }, [previewViewport?.height, previewViewport?.width]);

  return (
    <div ref={hostRef} className="deck-thumbnail-iframe-host">
      <iframe
        ref={frameRef}
        title={label}
        sandbox="allow-scripts"
        srcDoc={srcDoc}
        tabIndex={-1}
        onLoad={onReady}
      />
    </div>
  );
}

/**
 * Pure LRU step for the set of thumbnail indices that keep a live iframe.
 *
 * `prevOrder` is the previous mounted list in least→most recently relevant
 * order. Every currently `visible` index plus `activeIndex` moves to the
 * most-recent end; anything beyond `cap` falls off the least-recent end
 * unless it is visible or active right now. Indices outside `[0, count)` are
 * dropped (deck shrank). Returns `prevOrder` itself when nothing changed so
 * callers can bail out of state updates by identity.
 */
export function nextMountedThumbnails(
  prevOrder: readonly number[],
  visible: ReadonlySet<number>,
  activeIndex: number,
  count: number,
  cap: number = MOUNTED_THUMBNAIL_CAP,
): readonly number[] {
  const pinned = new Set<number>();
  for (const index of visible) {
    if (index >= 0 && index < count) pinned.add(index);
  }
  if (activeIndex >= 0 && activeIndex < count) pinned.add(activeIndex);

  const stale = prevOrder.filter((index) => index >= 0 && index < count && !pinned.has(index));
  const next = [...stale, ...[...pinned].sort((a, b) => a - b)];
  const evictable = Math.max(0, next.length - Math.max(cap, pinned.size));
  const bounded = evictable > 0 ? next.slice(evictable) : next;

  if (
    bounded.length === prevOrder.length
    && bounded.every((index, i) => index === prevOrder[i])
  ) {
    return prevOrder;
  }
  return bounded;
}

interface DeckThumbnailItemProps {
  index: number;
  active: boolean;
  mounted: boolean;
  label: string;
  listRef: RefObject<HTMLDivElement | null>;
  /**
   * Parsed deck for shadow-root single-slide rendering. When present a mounted
   * thumbnail renders a `<DeckSlideThumbnail>`; when null it falls back to the
   * full-deck iframe built by `getSrcDoc`.
   */
  parsedDeck: ParsedDeckThumbnails | null;
  previewViewport?: DeckThumbnailViewport | null;
  getSrcDoc: (index: number) => string;
  onSelect: (index: number) => void;
  onVisibilityChange: (index: number, inView: boolean) => void;
}

const DeckThumbnailItem = memo(function DeckThumbnailItem({
  index,
  active,
  mounted,
  label,
  listRef,
  parsedDeck,
  previewViewport,
  getSrcDoc,
  onSelect,
  onVisibilityChange,
}: DeckThumbnailItemProps) {
  // `once: false` so scrolling a thumbnail far away releases its slot in the
  // LRU window instead of pinning every slide ever seen. The list is the
  // observation root: thumbnails clipped by its overflow never intersect the
  // viewport, so a viewport root could not pre-mount the ones just below the
  // fold.
  const { ref, inView } = useInView<HTMLButtonElement>({
    once: false,
    rootMargin: '320px',
    root: listRef,
  });
  useEffect(() => {
    onVisibilityChange(index, inView);
  }, [index, inView, onVisibilityChange]);
  useEffect(() => () => onVisibilityChange(index, false), [index, onVisibilityChange]);

  // If the shadow build throws for this slide, drop to the iframe fallback.
  // Reset when the deck source (parsedDeck identity) or index changes so a new
  // deck retries the cheap path.
  const [shadowFailed, setShadowFailed] = useState(false);
  useEffect(() => setShadowFailed(false), [parsedDeck, index]);
  const useShadow = parsedDeck !== null && !shadowFailed;
  // Tie readiness to the renderer currently mounted in this item. Resetting a
  // boolean from an effect races the shadow child's layout effect: the child
  // can report ready first, then the parent's effect writes `false` and leaves
  // the loading cover over an otherwise-rendered slide forever. A source key
  // makes a new deck/fallback synchronously not-ready during render, while a
  // ready callback can only mark the source it belongs to.
  const thumbnailSource = useShadow ? parsedDeck : getSrcDoc;
  const [readySource, setReadySource] = useState<typeof thumbnailSource | null>(null);
  const thumbnailReady = mounted && readySource === thumbnailSource;
  useEffect(() => {
    if (!mounted) setReadySource(null);
  }, [mounted]);
  // The iframe fallback uses `getSrcDoc` (a function) as its source identity.
  // Wrap it so React stores that function instead of invoking it as a state
  // updater and leaving the loading cover permanently visible.
  const handleThumbnailReady = useCallback(
    () => setReadySource(() => thumbnailSource),
    [thumbnailSource],
  );
  const handleShadowError = useCallback(() => {
    setReadySource(null);
    setShadowFailed(true);
  }, []);

  return (
    <button
      ref={ref}
      type="button"
      className={`deck-thumbnail-button${active ? ' active' : ''}`}
      aria-current={active ? 'true' : undefined}
      title={label}
      onClick={() => onSelect(index)}
    >
      <span className="deck-thumbnail-number">{index + 1}</span>
      <span className="deck-thumbnail-frame" aria-hidden="true">
        {mounted ? (
          useShadow ? (
            <DeckSlideThumbnail
              parsed={parsedDeck}
              index={index}
              onError={handleShadowError}
              onReady={handleThumbnailReady}
            />
          ) : (
            <DeckIframeThumbnail
              label={label}
              srcDoc={getSrcDoc(index)}
              previewViewport={previewViewport}
              onReady={handleThumbnailReady}
            />
          )
        ) : null}
        {mounted && !thumbnailReady ? (
          <span className="deck-thumbnail-loading" aria-hidden="true" />
        ) : null}
      </span>
    </button>
  );
});

export interface DeckThumbnailRailProps {
  /** Number of slides to list. */
  count: number;
  /** Active slide index (highlighted + always mounted). */
  activeIndex: number;
  /** Display total for the per-slide accessibility label. */
  labelTotal: number;
  /**
   * Build the per-slide thumbnail document. Must be referentially stable for
   * a given deck source — its identity is the srcdoc cache key. Used only for
   * the iframe fallback (when `parsedDeck` is null or a slide fails to render).
   */
  buildThumbSrcDoc: (index: number) => string;
  /**
   * Parsed deck for shadow-root single-slide thumbnails. Null → every mounted
   * thumbnail uses the iframe fallback (decks we can't statically render).
   */
  parsedDeck?: ParsedDeckThumbnails | null;
  /** Live preview iframe viewport. Used to make responsive fallback thumbnails
   *  take the same media-query branch and line-wrap identically. */
  previewViewport?: DeckThumbnailViewport | null;
  onSelect: (index: number) => void;
}

export const DeckThumbnailRail = memo(function DeckThumbnailRail({
  count,
  activeIndex,
  labelTotal,
  buildThumbSrcDoc,
  parsedDeck = null,
  previewViewport = null,
  onSelect,
}: DeckThumbnailRailProps) {
  const t = useT();
  const listRef = useRef<HTMLDivElement | null>(null);
  const [visible, setVisible] = useState<ReadonlySet<number>>(() => new Set());
  const [mountedOrder, setMountedOrder] = useState<readonly number[]>([]);

  const onVisibilityChange = useCallback((index: number, inView: boolean) => {
    setVisible((prev) => {
      if (prev.has(index) === inView) return prev;
      const next = new Set(prev);
      if (inView) next.add(index);
      else next.delete(index);
      return next;
    });
  }, []);

  useEffect(() => {
    setMountedOrder((prev) => nextMountedThumbnails(prev, visible, activeIndex, count));
  }, [visible, activeIndex, count]);

  // Render-phase memo cache: one srcdoc per slide per deck source. A plain
  // Map (not per-item useMemo) so slides share the cache across LRU
  // mount/unmount churn.
  const srcDocCache = useMemo(() => new Map<number, string>(), [buildThumbSrcDoc]);
  const getSrcDoc = useCallback((index: number) => {
    let doc = srcDocCache.get(index);
    if (doc === undefined) {
      doc = buildThumbSrcDoc(index);
      srcDocCache.set(index, doc);
    }
    return doc;
  }, [srcDocCache, buildThumbSrcDoc]);

  const mounted = useMemo(() => new Set(mountedOrder), [mountedOrder]);

  return (
    <aside className="deck-thumbnail-rail" aria-label="Slides">
      <div className="deck-thumbnail-list" ref={listRef}>
        {Array.from({ length: count }, (_, index) => (
          <DeckThumbnailItem
            key={index}
            index={index}
            active={index === activeIndex}
            mounted={mounted.has(index)}
            label={t('fileViewer.speakerNotesSlide', {
              current: index + 1,
              total: labelTotal,
            })}
            listRef={listRef}
            parsedDeck={parsedDeck}
            previewViewport={previewViewport}
            getSrcDoc={getSrcDoc}
            onSelect={onSelect}
            onVisibilityChange={onVisibilityChange}
          />
        ))}
      </div>
    </aside>
  );
});
